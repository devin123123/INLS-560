import pygame, sys

pygame.init()
# Add Green and Dark Green
GREEN = (173, 204, 96)
DARK_GREEN = (43,51,24)

screen = pygame.display.set_mode((750,750)) # blank canvas

pygame.display.set_caption("560 Snake Game") # This is retro snake

clock = pygame.time.Clock() # Control the frame rate

# Game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Fill screen with GREEN
    screen.fill(GREEN)
    pygame.display.update()
    clock.tick(60)