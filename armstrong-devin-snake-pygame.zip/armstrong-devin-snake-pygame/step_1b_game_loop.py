import pygame, sys

pygame.init() # Makes pygame available

screen = pygame.display.set_mode((750,750)) # blank canvas

pygame.display.set_caption("560 Snake Game") # This is retro snake

clock = pygame.time.Clock() # Control the frame rate

# Game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    pygame.display.update()
    clock.tick(60)

    # When run, this presents a black screen. 