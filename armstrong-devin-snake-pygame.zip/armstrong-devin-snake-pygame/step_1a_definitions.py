import pygame, sys

pygame.init() # Makes pygame available

screen = pygame.display.set_mode((750,750)) # blank canvas

pygame.display.set_caption("560 Snake Game") # This is retro snake

clock = pygame.time.Clock() # Control the frame rate